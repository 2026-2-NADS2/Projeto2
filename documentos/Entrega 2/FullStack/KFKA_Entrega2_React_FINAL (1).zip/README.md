# KFKA

Projeto Interdisciplinar do 2º semestre de Análise e Desenvolvimento de Sistemas da FECAP, feito pelo grupo KFKA Tech.

Integrantes: Vitor de Moura Lima, João Henrique Percino de Albuquerque e Gabriel Barbosa da Silva Cabral.

## Sobre o projeto

A KFKA é uma plataforma para ajudar a comunicação entre escola e família no Ensino Fundamental. O professor registra como o aluno foi no bimestre (média, avaliação e algumas tags), a coordenação revisa antes de liberar, e o responsável consegue ver o relatório do filho, confirmar que leu e mandar uma observação para a escola.

Tem três tipos de acesso: administrador (coordenação), professor e responsável.

Nesta entrega a gente refez o front-end em React, consumindo a API em Node/Express que já tinha sido feita na Entrega 1, com os dados salvos no MySQL.

## Tecnologias

- React com Vite e React Router no front-end
- Node.js com Express no back-end
- MySQL como banco de dados

## Pastas

- `back_end/`: API, conexão com o banco e o arquivo `sql/schema.sql`
- `front_end/`: aplicação React
  - `src/services/api.js`: todas as chamadas para a API ficam aqui
  - `src/pages/`: telas, separadas por perfil (admin, professor e responsavel)
  - `src/components/`: partes reaproveitadas entre as telas, como a tabela, a paginação e as mensagens

## Como rodar

Precisa ter o Node.js instalado e um MySQL rodando (usamos o do XAMPP).

### Banco de dados

Abra o phpMyAdmin ou o MySQL Workbench e execute o arquivo `back_end/sql/schema.sql`. Ele cria o banco `kfka_db`, as tabelas e já coloca alguns dados para teste.

### Back-end

Dentro da pasta `back_end`:

```bash
copy .env.example .env
npm install
npm start
```

Se o seu MySQL tiver senha, coloque ela no `DB_PASSWORD` do arquivo `.env`. A API sobe em http://localhost:3000.

### Front-end

Com o back-end rodando, abra outro terminal na pasta `front_end`:

```bash
copy .env.example .env
npm install
npm run dev
```

Depois é só abrir http://localhost:5173 no navegador.

No Linux ou no Mac, use `cp` no lugar de `copy`.

## URL da API

O endereço da API fica no arquivo `front_end/.env`:

```
VITE_API_URL=http://localhost:3000/api
```

Se a API estiver rodando em outra porta ou em outro servidor, é só trocar esse valor e reiniciar o `npm run dev`.

## Logins de teste

- Administrador: `admin` / `123456`
- Professor: `102030` / `123456`
- Responsável: `987.654.321-00` / `123456`

## Fluxo de telas

A primeira tela é a página inicial. Clicando em "Entrar" você escolhe o perfil (responsável, professor ou administrador) e faz o login.

**Administrador:** cai num menu com as áreas de gestão. Por ele dá para cadastrar turmas, disciplinas, professores, alunos, responsáveis e tags, definir as datas em que os professores podem lançar notas em cada bimestre, revisar e publicar os acompanhamentos e ver os relatórios com opção de exportar para Excel. Em todos os cadastros dá para criar, editar, ativar/inativar e excluir.

**Professor:** vê só as turmas e disciplinas dele. Escolhe a sala, lança o acompanhamento do aluno e pode salvar como rascunho ou já mandar para revisão. Também vê o que a coordenação devolveu para ajustar e as observações que os responsáveis deixaram.

**Responsável:** vê só os alunos ligados a ele. Escolhe o bimestre, lê os relatórios que já foram publicados, confirma que leu, manda observações para a escola e pode baixar o relatório em PDF.

Um teste rápido que passa pelo sistema inteiro: o administrador cadastra uma turma, um aluno e o responsável dele e vincula um professor. O professor lança o acompanhamento e envia. O administrador revisa e publica. O responsável entra, lê, confirma a ciência e baixa o PDF. Por último, o administrador exporta os dados para Excel na tela de relatórios.

## Rotas da API

| Método | Rota | Descrição |
|---|---|---|
| POST | /api/login | login |
| POST | /api/definir-senha | responsável cria a senha no primeiro acesso |
| POST | /api/recuperar-senha | recuperação de senha |
| GET | /api/:recurso | lista todos |
| GET | /api/:recurso/:id | busca um pelo id |
| POST | /api/:recurso | cadastra |
| PUT | /api/:recurso/:id | atualiza |
| DELETE | /api/:recurso/:id | exclui |
| GET | /api/historico | histórico de alterações dos acompanhamentos |

Recursos: `turmas`, `disciplinas`, `professores`, `alunos`, `responsaveis`, `tags`, `bimestres` e `acompanhamentos`.
