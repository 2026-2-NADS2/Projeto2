# KFKA - Plataforma Web de Acompanhamento Escolar (Entrega 2)

Sistema Web Full Stack responsivo para registro, revisão, publicação e acompanhamento bimestral do desenvolvimento de alunos do Ensino Fundamental.

## 1. Tecnologias Utilizadas
- **Front-end**: HTML5, CSS3, JavaScript (ES6+ SPA modularizado em `config.js`, `api.js` e `app.js`).
- **Back-end**: Node.js + Express (Arquitetura em camadas com POO em `SistemaKFKA.js`).
- **Banco de Dados**: MySQL (`mysql2/promise`) com tabelas relacionais, índices e `VIEW`.

## 2. Como Configurar e Rodar o Projeto

### Passo 1: Banco de Dados MySQL
1. Abra o seu cliente MySQL (MySQL Workbench, DBeaver ou terminal).
2. Execute todo o conteúdo do arquivo `backend/sql/schema.sql`. Ele criará o banco `kfka_db`, as tabelas, índices, a view `vw_relatorio_acompanhamentos` e inserirá os dados iniciais.

### Passo 2: Back-end (API Node.js)
1. Acesse a pasta `backend`:
   ```bash
   cd backend
   npm install