window.KFKA_CONFIG = {
  API_BASE_URL: localStorage.getItem('kfka_api_url') || 'http://localhost:3000/api',
  ANO_LETIVO_PADRAO: '2026'
};