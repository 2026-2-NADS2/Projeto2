const api = {
  async requisicao(endpoint, opcoes = {}) {
    const url = `${window.KFKA_CONFIG.API_BASE_URL}${endpoint}`;
    const config = {
      headers: { 'Content-Type': 'application/json' },
      ...opcoes
    };

    let resposta;
    try {
      resposta = await fetch(url, config);
    } catch {
      throw new Error(
        'Não foi possível conectar ao servidor Node.js. Verifique se o comando npm start está ativo.'
      );
    }

    const dados = await resposta.json().catch(() => ({}));
    if (!resposta.ok) {
      throw new Error(dados.erro || `Erro HTTP ${resposta.status}`);
    }
    return dados;
  },

  login(credenciais) {
    return this.requisicao('/login', {
      method: 'POST',
      body: JSON.stringify(credenciais)
    });
  },

  definirSenha(identificador, novaSenha) {
    return this.requisicao('/definir-senha', {
      method: 'POST',
      body: JSON.stringify({ identificador, novaSenha })
    });
  },

  recuperarSenha(identificador) {
    return this.requisicao('/recuperar-senha', {
      method: 'POST',
      body: JSON.stringify({ identificador })
    });
  },

  listar(rota, query = '') {
    const sufixo = query ? `?${query}` : '';
    return this.requisicao(`/${rota}${sufixo}`);
  },

  buscarPorId(rota, id) {
    return this.requisicao(`/${rota}/${id}`);
  },

  criar(rota, dados) {
    return this.requisicao(`/${rota}`, {
      method: 'POST',
      body: JSON.stringify(dados)
    });
  },

  atualizar(rota, id, dados) {
    return this.requisicao(`/${rota}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(dados)
    });
  },

  remover(rota, id) {
    return this.requisicao(`/${rota}/${id}`, {
      method: 'DELETE'
    });
  }
};