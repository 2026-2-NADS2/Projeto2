const app = document.querySelector('#app');

const titulos = {
  aluno: 'Portal do Aluno e Responsável',
  professor: 'Portal do Professor',
  administrador: 'Central de Cadastros e Gestão Escolar',
  turmas: 'Cadastro e Vínculos de Turmas',
  disciplinas: 'Cadastro de Áreas e Disciplinas',
  professores: 'Cadastro de Professores',
  alunos: 'Cadastro de Alunos',
  responsaveis: 'Cadastro de Responsáveis',
  tags: 'Cadastro de Tags',
  bimestres: 'Períodos de Digitação dos Bimestres',
  revisao: 'Revisão e Publicação de Acompanhamentos',
  relatorios: 'Relatórios Gerenciais, Auditoria e Exportação Excel'
};

const limpo = valor =>
  String(valor ?? '').replace(
    /[&<>"']/g,
    letra =>
      ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      })[letra]
  );

const normalizarTexto = txt => String(txt ?? '').trim().toLowerCase();

const caminho = () =>
  decodeURIComponent(location.hash.slice(1).split('?')[0] || '/login').replace(/^\/+/, '');

const parametrosUrl = () => new URLSearchParams(location.hash.split('?')[1] || '');

function obterSessao() {
  try {
    return JSON.parse(sessionStorage.getItem('kfka_usuario')) || null;
  } catch {
    return null;
  }
}

function salvarSessao(usuario) {
  sessionStorage.setItem('kfka_usuario', JSON.stringify(usuario));
}

function aviso(mensagem, tipo = 'success') {
  const lugar = document.querySelector('#aviso');
  if (lugar) {
    lugar.innerHTML = `
      <div class="message ${tipo}" role="status">
        ${limpo(mensagem)}
      </div>
    `;
    lugar.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
}

function casca(titulo, conteudo, home = '/administrador') {
  const sessao = obterSessao();
  const nomeExibicao = sessao ? sessao.nome : 'Visitante';

  const contextoTopo =
    home === '/aluno'
      ? `
        <div class="contexto-aluno">
          <span>Responsável: ${limpo(nomeExibicao)}</span>
          <span>Ano Letivo: 2026</span>
        </div>
      `
      : `
        <div class="contexto-aluno">
          <span>Usuário: ${limpo(nomeExibicao)}</span>
        </div>
      `;

  app.innerHTML = `
    <div class="shell">
      <header class="topbar">
        <div class="topbar-left">
          <a class="brand" href="#${home}" aria-label="KFKA início">
            K F K <span>Λ</span>
          </a>
          ${contextoTopo}
        </div>
        <strong class="heading">${limpo(titulo)}</strong>
        <span class="right">
          <a class="home-link" href="#${home}">Início</a>
          <a href="#/login" id="btn-logout">Sair</a>
        </span>
      </header>
      <main class="content">
        <div id="aviso"></div>
        ${conteudo}
      </main>
    </div>
  `;

  const btnLogout = document.querySelector('#btn-logout');
  if (btnLogout) {
    btnLogout.onclick = () => sessionStorage.removeItem('kfka_usuario');
  }
}

function acesso() {
  app.innerHTML = `
    <main class="login">
      <section class="login-box">
        <h1 class="login-logo">K F K <span>Λ</span></h1>
        <div class="role-choice">
          <a class="login-input" href="#/acesso?perfil=responsavel">RESPONSÁVEL</a>
          <a class="login-input" href="#/acesso?perfil=professor">PROFESSOR</a>
          <a class="login-input" href="#/acesso?perfil=administrador">ADMINISTRADOR</a>
        </div>
        <p class="muted">
          Plataforma Integrada MySQL · API: ${limpo(window.KFKA_CONFIG.API_BASE_URL)}
        </p>
      </section>
    </main>
  `;
}

function telaAcesso() {
  const perfil = parametrosUrl().get('perfil') || 'responsavel';
  const nomesPerfis = {
    responsavel: 'RESPONSÁVEL',
    professor: 'PROFESSOR',
    administrador: 'ADMINISTRADOR'
  };
  const tituloPerfil = nomesPerfis[perfil] || perfil.toUpperCase();

  const label =
    perfil === 'professor'
      ? 'RA ou E-mail'
      : perfil === 'administrador'
        ? 'Usuário'
        : 'CPF ou Matrícula do Aluno';

  const sugestaoUsuario =
    perfil === 'professor' ? '102030' : perfil === 'administrador' ? 'admin' : '987.654.321-00';

  app.innerHTML = `
    <main class="login">
      <section class="login-box">
        <h1 class="login-logo">K F K <span>Λ</span></h1>
        <form id="login-form" class="login-form">
          <h2>Acesso ${limpo(tituloPerfil)}</h2>
          <div id="aviso"></div>

          <label for="usuario">${label}</label>
          <input
            class="login-input"
            id="usuario"
            name="usuario"
            value="${sugestaoUsuario}"
            placeholder="${label}"
            required
          >

          <label for="senha">Senha</label>
          <input
            class="login-input"
            id="senha"
            type="password"
            name="senha"
            value="123456"
            placeholder="Digite sua senha"
            required
          >

          <button class="primary" type="submit" id="btn-entrar">Confirmar</button>

          <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px; margin-top:8px; font-size:13px;">
            <a href="#/login">← Voltar</a>
            ${
              perfil === 'responsavel'
                ? `<button type="button" class="back" id="btn-criar-senha" style="text-decoration:underline; font-weight:bold;">
                     Primeiro acesso / Criar senha
                   </button>`
                : ''
            }
            <button type="button" class="back" id="btn-recuperar" style="text-decoration:underline;">
              Esqueci minha senha
            </button>
          </div>
        </form>

        <form id="form-nova-senha" class="login-form hidden" style="margin-top:16px; border-top:1px solid #ccc; padding-top:14px;">
          <h3>Criar / Definir Senha do Responsável</h3>
          <p class="muted" style="font-size:12px;">
            Digite seu CPF cadastrado pelo Administrador ou o número de Matrícula do seu filho(a) para definir sua senha:
          </p>
          <label for="id-ativacao">Seu CPF ou Matrícula do Aluno</label>
          <input
            class="login-input"
            id="id-ativacao"
            placeholder="Ex: 123.456.789-00 ou Matrícula"
            required
          >
          <label for="nova-senha-resp">Crie sua Senha</label>
          <input
            class="login-input"
            id="nova-senha-resp"
            type="password"
            minlength="4"
            placeholder="Mínimo 4 caracteres"
            required
          >
          <button class="primary" type="submit">Salvar Nova Senha</button>
        </form>
      </section>
    </main>
  `;

  const btnCriarSenha = document.querySelector('#btn-criar-senha');
  const formNovaSenha = document.querySelector('#form-nova-senha');
  if (btnCriarSenha && formNovaSenha) {
    btnCriarSenha.onclick = () => {
      formNovaSenha.classList.toggle('hidden');
      const valorAtual = document.querySelector('#usuario').value.trim();
      if (valorAtual) {
        document.querySelector('#id-ativacao').value = valorAtual;
      }
    };

    formNovaSenha.onsubmit = async e => {
      e.preventDefault();
      const identificador = document.querySelector('#id-ativacao').value.trim();
      const novaSenha = document.querySelector('#nova-senha-resp').value.trim();
      try {
        const resp = await api.definirSenha(identificador, novaSenha);
        aviso(resp.mensagem, 'success');
        document.querySelector('#usuario').value = identificador;
        document.querySelector('#senha').value = novaSenha;
        formNovaSenha.classList.add('hidden');
      } catch (err) {
        aviso(err.message, 'error');
      }
    };
  }

  document.querySelector('#btn-recuperar').onclick = async () => {
    const identificador = document.querySelector('#usuario').value.trim();
    if (!identificador) {
      return aviso(`Preencha o campo ${label} para solicitar a recuperação de senha.`, 'error');
    }
    try {
      const resp = await api.recuperarSenha(identificador);
      aviso(resp.mensagem, 'success');
    } catch (err) {
      aviso(err.message, 'error');
    }
  };

  document.querySelector('#login-form').addEventListener('submit', async e => {
    e.preventDefault();
    if (!e.target.reportValidity()) return;

    const btn = document.querySelector('#btn-entrar');
    btn.disabled = true;
    btn.textContent = 'Autenticando...';

    try {
      const f = new FormData(e.target);
      const resposta = await api.login({
        usuario: f.get('usuario'),
        senha: f.get('senha'),
        perfil
      });

      salvarSessao(resposta.usuario);
      location.hash =
        perfil === 'responsavel'
          ? '#/aluno'
          : perfil === 'professor'
            ? '#/professor'
            : '#/administrador';
    } catch (err) {
      aviso(err.message, 'error');
      btn.disabled = false;
      btn.textContent = 'Confirmar';
    }
  });
}

function menuAdmin() {
  const itensMenu = [
    { rota: 'turmas', rotulo: 'Criar Turmas / Salas' },
    { rota: 'disciplinas', rotulo: 'Áreas e Disciplinas' },
    { rota: 'professores', rotulo: 'Professores e Salas de Aula' },
    { rota: 'alunos', rotulo: 'Alunos e Matrícula na Turma' },
    { rota: 'responsaveis', rotulo: 'Responsáveis e Acesso' },
    { rota: 'tags', rotulo: 'Tags de Acompanhamento' },
    { rota: 'bimestres', rotulo: 'Períodos Bimestrais (Janelas)' },
    { rota: 'revisao', rotulo: 'Revisão e Publicação Editorial' },
    { rota: 'relatorios', rotulo: 'Relatórios, Auditoria e Excel' }
  ];

  casca(
    titulos.administrador,
    `
      <h1 class="title" style="text-align:center; margin-bottom:24px;">SELECIONE A ÁREA DE GESTÃO ESCOLAR</h1>
      <nav
        class="menu"
        aria-label="Áreas de gestão"
        style="display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); max-width:960px; width:100%; margin:0 auto; gap:16px; align-items:stretch;"
      >
        ${itensMenu
          .map(
            item => `
              <a
                class="menu-tile"
                href="#/${item.rota}"
                style="display:flex; align-items:center; justify-content:center; text-align:center; min-height:76px; height:100%; padding:16px; box-sizing:border-box;"
              >
                ${limpo(item.rotulo)}
              </a>
            `
          )
          .join('')}
      </nav>
    `
  );
}

function linhaCampo(nome, rotulo, tipo = 'text', obrigatorio = true, placeholder = '') {
  return `
    <label class="field">
      ${rotulo}
      <input name="${nome}" type="${tipo}" placeholder="${limpo(placeholder)}" ${obrigatorio ? 'required' : ''}>
    </label>
  `;
}

function select(nome, rotulo, opcoes) {
  return `
    <label class="field">
      ${rotulo}
      <select name="${nome}" required>
        ${opcoes.map(o => `<option value="${limpo(o)}">${limpo(o)}</option>`).join('')}
      </select>
    </label>
  `;
}

function tabelaCRUD(colunas, linhas) {
  if (!linhas.length) {
    return `<div class="panel">Nenhum registro cadastrado no banco de dados.</div>`;
  }

  return `
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            ${colunas.map(c => `<th>${limpo(c)}</th>`).join('')}
            <th>Status</th>
            <th>Ações (CRUD)</th>
          </tr>
        </thead>
        <tbody>
          ${linhas
            .map(
              l => `
                <tr>
                  ${colunas.map((_, i) => `<td>${limpo(l.valores[i])}</td>`).join('')}
                  <td>
                    <span class="badge ${l.ativo ? 'Ativo' : 'Inativo'}">
                      ${l.ativo ? 'Ativo' : 'Inativo'}
                    </span>
                  </td>
                  <td>
                    <div class="table-actions">
                      <button class="small-button editar-item" data-id="${l.id}">
                        Editar
                      </button>
                      <button class="small-button secondary alternar-ativo" data-id="${l.id}" data-ativo="${l.ativo ? 1 : 0}">
                        ${l.ativo ? 'Inativar' : 'Ativar'}
                      </button>
                      <button class="small-button danger excluir-item" data-id="${l.id}">
                        Excluir
                      </button>
                    </div>
                  </td>
                </tr>
              `
            )
            .join('')}
        </tbody>
      </table>
    </div>
  `;
}

const configs = {
  turmas: {
    singular: 'Turma',
    campos: `
      ${select('ano', 'Ano letivo', ['2026', '2027'])}
      ${linhaCampo('nome', 'Nome da Sala / Turma', 'text', true, 'Ex: 7º Ano A, 7º Ano B, 8º Ano A')}
      ${select('turno', 'Turno', ['Manhã', 'Tarde'])}
      ${linhaCampo('capacidade', 'Capacidade máxima de alunos', 'number', true, 'Ex: 30')}
      <div class="wide field">
        Selecione as disciplinas desta turma:
        <div class="check-row" id="check-disciplinas-turma">
          ${['Matemática', 'Português', 'Ciências', 'História']
            .map(n => `<label><input type="checkbox" name="disciplinas" value="${n}">${n}</label>`)
            .join('')}
        </div>
      </div>
    `,
    cols: ['Ano', 'Sala / Turma', 'Turno', 'Disciplinas associadas', 'Ocupação / Capacidade'],
    valores: (x, extras) => {
      const matriculados = (extras.alunos || []).filter(
        a => normalizarTexto(a.serie) === normalizarTexto(x.nome) && (a.ativo === undefined || Boolean(a.ativo))
      ).length;
      const cap = Number(x.capacidade) || 0;
      const statusLotacao = matriculados >= cap && cap > 0 ? ' (LOTADA)' : '';
      return [
        x.ano || '2026',
        x.nome,
        x.turno,
        x.disciplinas,
        `${matriculados} / ${cap} alunos${statusLotacao}`
      ];
    }
  },

  disciplinas: {
    singular: 'Disciplina',
    campos: `
      ${linhaCampo('nome', 'Nome da disciplina', 'text', true, 'Ex: Geografia')}
      ${select('area', 'Área do conhecimento', [
        'Ciências Exatas',
        'Linguagens e Códigos',
        'Ciências da Natureza',
        'Ciências Humanas'
      ])}
    `,
    cols: ['Disciplina', 'Área do Conhecimento'],
    valores: x => [x.nome, x.area]
  },

  professores: {
    singular: 'Professor',
    campos: `
      ${linhaCampo('nome', 'Nome do professor', 'text', true, 'Ex: Julio Cesar')}
      ${linhaCampo('ra', 'Registro Acadêmico (RA - Usado no Login)', 'text', true, 'Ex: 102030')}
      ${linhaCampo('email', 'Email do professor', 'email', true, 'professor@kfka.com')}
      <div class="wide field">
        <span>
          <strong>Salas / Turmas em que este professor dá aula</strong>
          (Marque todas as salas dele; para criar uma sala nova vá em <a href="#/turmas" style="text-decoration:underline; display:inline;">Criar Turmas</a>):
        </span>
        <div class="check-row" id="check-turmas-prof-admin" style="margin-top:6px;">
          Carregando salas cadastradas...
        </div>
      </div>
      <div class="wide field">
        <span>
          <strong>Disciplinas lecionadas</strong>
          (Marque uma ou mais disciplinas que este professor leciona):
        </span>
        <div class="check-row" id="check-disc-prof-admin" style="margin-top:6px;">
          ${['Matemática', 'Português', 'Ciências', 'História', 'Geografia']
            .map(n => `<label><input type="checkbox" name="disciplina" value="${n}">${n}</label>`)
            .join('')}
        </div>
      </div>
    `,
    cols: ['Professor', 'RA (Login)', 'Email', 'Salas de Aula', 'Disciplinas Lecionadas'],
    valores: x => [x.nome, x.ra, x.email, x.turma || x.aulas, x.disciplina || '—']
  },

  responsaveis: {
    singular: 'Responsável',
    campos: `
      ${linhaCampo('nome', 'Nome do responsável')}
      ${linhaCampo('email', 'Email do responsável', 'email')}
      ${linhaCampo('telefone', 'Telefone', 'tel')}
      ${linhaCampo('cpf', 'CPF do responsável (Usado para Login)')}
      ${select('parentesco', 'Grau de parentesco', ['Pai', 'Mãe', 'Responsável Legal'])}
      <label class="field">
        Dependente (Aluno) vinculado
        <input name="aluno" list="lista-alunos-sugestao" placeholder="Selecione ou digite o nome do aluno" required>
        <datalist id="lista-alunos-sugestao"></datalist>
      </label>
      ${linhaCampo(
        'senha',
        'Senha inicial de acesso (opcional)',
        'text',
        false,
        'Padrão 123456 ou criada pelo responsável'
      )}
    `,
    cols: ['Responsável', 'CPF (Login)', 'Email', 'Telefone', 'Dependente vinculado'],
    valores: x => [x.nome, x.cpf, x.email, x.telefone, x.aluno]
  },

  alunos: {
    singular: 'Aluno',
    campos: `
      ${linhaCampo('nome', 'Nome do aluno')}
      ${linhaCampo('matricula', 'Número de matrícula')}
      <label class="field">
        Sala / Turma do aluno (Para criar nova sala vá em Turmas)
        <select name="serie" id="select-turma-aluno-admin" required></select>
      </label>
      <label class="field">
        Responsável vinculado
        <input name="responsavel" list="lista-responsaveis-sugestao" placeholder="Nome do responsável" required>
        <datalist id="lista-responsaveis-sugestao"></datalist>
      </label>
    `,
    cols: ['Nome do aluno', 'Matrícula', 'Sala / Turma', 'Responsável vinculado'],
    valores: x => [x.nome, x.matricula, x.serie, x.responsavel]
  },

  tags: {
    singular: 'Tag',
    campos: `
      ${linhaCampo('nome', 'Nome da tag')}
      ${select('categoria', 'Categoria da tag', ['Positiva', 'Atenção', 'Desempenho'])}
    `,
    cols: ['Tag', 'Categoria'],
    valores: x => [x.nome, x.categoria || 'Desempenho']
  }
};

async function cadastro(rota) {
  const c = configs[rota];

  casca(
    titulos[rota],
    `
      <h1 class="section-title" id="form-titulo">Cadastrar ${c.singular}</h1>
      <form id="cadastro" class="panel">
        <div class="form-grid">
          ${c.campos}
        </div>
        <div class="form-actions">
          <button class="primary" type="submit" id="btn-salvar">Salvar ${c.singular}</button>
          <button class="small-button secondary hidden" type="button" id="btn-cancelar-edicao">
            Cancelar Edição
          </button>
        </div>
      </form>

      <h2 class="section-title">${c.singular}s cadastrados no MySQL</h2>
      <div id="lista" class="loading" role="status">
        Carregando dados da API...
      </div>
    `
  );

  const form = document.querySelector('#cadastro');
  const formTitulo = document.querySelector('#form-titulo');
  const btnSalvar = document.querySelector('#btn-salvar');
  const btnCancelar = document.querySelector('#btn-cancelar-edicao');
  const containerLista = document.querySelector('#lista');

  let cacheExtras = { turmas: [], alunos: [], disciplinas: [], responsaveis: [] };

  async function atualizarOpcoesDinamicasAdmin() {
    try {
      const [turmasBanco, alunosBanco, discBanco, respBanco] = await Promise.all([
        api.listar('turmas'),
        api.listar('alunos'),
        api.listar('disciplinas'),
        api.listar('responsaveis')
      ]);

      cacheExtras = {
        turmas: turmasBanco,
        alunos: alunosBanco,
        disciplinas: discBanco,
        responsaveis: respBanco
      };

      const nomesTurmas = [
        ...new Set([
          ...turmasBanco
            .filter(t => t.ativo === undefined || Boolean(t.ativo))
            .map(t => String(t.nome).trim()),
          '6º Ano A',
          '6º Ano B',
          '7º Ano A',
          '7º Ano B',
          '8º Ano A'
        ])
      ];

      const nomesDisciplinas = discBanco.length
        ? [...new Set(discBanco.filter(d => d.ativo === undefined || Boolean(d.ativo)).map(d => String(d.nome).trim()))]
        : ['Matemática', 'Português', 'Ciências', 'História', 'Geografia'];

      if (rota === 'turmas') {
        const divDisc = document.querySelector('#check-disciplinas-turma');
        if (divDisc && nomesDisciplinas.length) {
          divDisc.innerHTML = nomesDisciplinas
            .map(n => `<label><input type="checkbox" name="disciplinas" value="${limpo(n)}">${limpo(n)}</label>`)
            .join('');
        }
      }

      if (rota === 'professores') {
        const divCheckTurmas = document.querySelector('#check-turmas-prof-admin');
        if (divCheckTurmas) {
          divCheckTurmas.innerHTML = nomesTurmas
            .map(n => `<label><input type="checkbox" name="turma" value="${limpo(n)}">${limpo(n)}</label>`)
            .join('');
        }
        const divCheckDisc = document.querySelector('#check-disc-prof-admin');
        if (divCheckDisc && nomesDisciplinas.length) {
          divCheckDisc.innerHTML = nomesDisciplinas
            .map(n => `<label><input type="checkbox" name="disciplina" value="${limpo(n)}">${limpo(n)}</label>`)
            .join('');
        }
      }

      if (rota === 'alunos') {
        const selTurma = document.querySelector('#select-turma-aluno-admin');
        if (selTurma) {
          selTurma.innerHTML = nomesTurmas
            .map(nomeSala => {
              const infoTurma = turmasBanco.find(
                t => normalizarTexto(t.nome) === normalizarTexto(nomeSala)
              );
              const qtdAtual = alunosBanco.filter(
                a =>
                  normalizarTexto(a.serie) === normalizarTexto(nomeSala) &&
                  (a.ativo === undefined || Boolean(a.ativo))
              ).length;

              if (infoTurma) {
                const cap = Number(infoTurma.capacidade) || 0;
                const lotada = qtdAtual >= cap && cap > 0 ? ' - LOTADA' : '';
                return `<option value="${limpo(nomeSala)}">${limpo(nomeSala)} (${qtdAtual}/${cap} alunos${lotada})</option>`;
              }
              return `<option value="${limpo(nomeSala)}">${limpo(nomeSala)} (${qtdAtual} alunos)</option>`;
            })
            .join('');
        }

        const dlResp = document.querySelector('#lista-responsaveis-sugestao');
        if (dlResp && respBanco.length) {
          dlResp.innerHTML = respBanco.map(r => `<option value="${limpo(r.nome)}"></option>`).join('');
        }
      }

      if (rota === 'responsaveis') {
        const dlAlunos = document.querySelector('#lista-alunos-sugestao');
        if (dlAlunos && alunosBanco.length) {
          dlAlunos.innerHTML = alunosBanco.map(a => `<option value="${limpo(a.nome)}"></option>`).join('');
        }
      }
    } catch {
    }
  }

  await atualizarOpcoesDinamicasAdmin();

  function limparEdicao() {
    delete form.dataset.editarId;
    form.reset();
    formTitulo.textContent = `Cadastrar ${c.singular}`;
    btnSalvar.textContent = `Salvar ${c.singular}`;
    btnCancelar.classList.add('hidden');
  }

  btnCancelar.onclick = limparEdicao;

  async function carregarLista() {
    containerLista.className = 'loading';
    containerLista.textContent = 'Carregando dados da API...';

    try {
      await atualizarOpcoesDinamicasAdmin();
      const itens = await api.listar(rota);
      if (caminho() !== rota) return;

      containerLista.className = '';
      containerLista.innerHTML = tabelaCRUD(
        c.cols,
        itens.map(x => ({
          id: x.id,
          ativo: x.ativo !== undefined ? Boolean(x.ativo) : true,
          valores: c.valores(x, cacheExtras)
        }))
      );

      containerLista.querySelectorAll('.editar-item').forEach(btn => {
        btn.onclick = async () => {
          try {
            const item = await api.buscarPorId(rota, btn.dataset.id);
            form.dataset.editarId = item.id;
            formTitulo.textContent = `Editando ${c.singular} #${item.id} (${item.nome})`;
            btnSalvar.textContent = `Atualizar ${c.singular}`;
            btnCancelar.classList.remove('hidden');

            Object.keys(item).forEach(chave => {
              const campo = form.elements[chave];
              if (!campo) return;

              if (rota === 'turmas' && chave === 'disciplinas') {
                const selecionadas = String(item.disciplinas || '')
                  .split(/[,;]/)
                  .map(s => normalizarTexto(s));
                form.querySelectorAll('[name="disciplinas"]').forEach(chk => {
                  chk.checked = selecionadas.includes(normalizarTexto(chk.value));
                });
              } else if (rota === 'professores' && chave === 'turma') {
                const selecionadas = String(item.turma || '')
                  .split(/[,;]/)
                  .map(s => normalizarTexto(s));
                form.querySelectorAll('[name="turma"]').forEach(chk => {
                  chk.checked = selecionadas.includes(normalizarTexto(chk.value));
                });
              } else if (rota === 'professores' && chave === 'disciplina') {
                const selecionadas = String(item.disciplina || '')
                  .split(/[,;]/)
                  .map(s => normalizarTexto(s));
                form.querySelectorAll('[name="disciplina"]').forEach(chk => {
                  chk.checked = selecionadas.includes(normalizarTexto(chk.value));
                });
              } else {
                campo.value = item[chave];
              }
            });

            form.scrollIntoView({ behavior: 'smooth' });
          } catch (err) {
            aviso(err.message, 'error');
          }
        };
      });

      containerLista.querySelectorAll('.alternar-ativo').forEach(btn => {
        btn.onclick = async () => {
          const novoEstado = Number(btn.dataset.ativo) === 1 ? 0 : 1;
          try {
            await api.atualizar(rota, btn.dataset.id, { ativo: novoEstado });
            await carregarLista();
            aviso(`Status do registro atualizado com sucesso.`);
          } catch (err) {
            aviso(err.message, 'error');
          }
        };
      });

      containerLista.querySelectorAll('.excluir-item').forEach(btn => {
        btn.onclick = async () => {
          if (!window.confirm(`Tem certeza que deseja excluir este registro de ${c.singular}?`)) {
            return;
          }
          try {
            await api.remover(rota, btn.dataset.id);
            await carregarLista();
            aviso(`${c.singular} excluído com sucesso do banco de dados.`);
          } catch (err) {
            aviso(err.message, 'error');
          }
        };
      });
    } catch (err) {
      containerLista.className = '';
      containerLista.innerHTML = `
        <div class="message error">
          ${limpo(err.message)}
          <button class="small-button" id="repetir">Tentar novamente</button>
        </div>
      `;
      document.querySelector('#repetir').onclick = carregarLista;
    }
  }

  await carregarLista();

  form.onsubmit = async e => {
    e.preventDefault();
    if (!form.reportValidity()) return;

    const f = new FormData(form);
    const dados = Object.fromEntries(f.entries());

    if (rota === 'turmas') {
      dados.nome = String(dados.nome || '').trim();
      dados.disciplinas = f.getAll('disciplinas').join(', ');
      if (!dados.disciplinas) {
        return aviso('Escolha ao menos uma disciplina para a turma.', 'error');
      }
      if (Number(dados.capacidade) < 1) {
        return aviso('A capacidade da turma deve ser maior que zero.', 'error');
      }
    }

    if (rota === 'professores') {
      dados.turma = f.getAll('turma').join(', ');
      if (!dados.turma) {
        return aviso('Marque ao menos uma sala de aula para o professor.', 'error');
      }
      dados.disciplina = f.getAll('disciplina').join(', ');
      if (!dados.disciplina) {
        return aviso('Marque ao menos uma disciplina lecionada para o professor.', 'error');
      }
    }

    try {
      btnSalvar.disabled = true;
      const editId = form.dataset.editarId;
      if (editId) {
        await api.atualizar(rota, editId, dados);
        aviso(`${c.singular} atualizado com sucesso!`);
      } else {
        await api.criar(rota, dados);
        aviso(
          rota === 'turmas'
            ? `Sala "${dados.nome}" criada! Agora você já pode vinculá-la aos Professores e matricular Alunos nela.`
            : rota === 'responsaveis'
              ? `Responsável cadastrado! Ele já pode acessar o portal com o CPF (${dados.cpf}) ou Matrícula do aluno.`
              : `${c.singular} cadastrado com sucesso!`
        );
      }
      limparEdicao();
      await carregarLista();
    } catch (err) {
      aviso(err.message, 'error');
    } finally {
      btnSalvar.disabled = false;
    }
  };
}

async function telaBimestres() {
  casca(
    titulos.bimestres,
    `
      <h1 class="section-title">Configurar Janelas de Digitação dos 4 Bimestres</h1>
      <div id="lista-bimestres" class="loading">Carregando períodos bimestrais...</div>
    `
  );

  const container = document.querySelector('#lista-bimestres');

  async function carregar() {
    try {
      const bimestres = await api.listar('bimestres');
      container.className = 'cards';
      container.innerHTML = bimestres
        .sort((a, b) => a.id - b.id)
        .map(b => {
          const abertura = String(b.data_abertura || '').slice(0, 16).replace(' ', 'T');
          const encerramento = String(b.data_encerramento || '').slice(0, 16).replace(' ', 'T');
          return `
            <form class="record form-bimestre" data-id="${b.id}">
              <div class="record-head">
                <strong>${limpo(b.nome)} (${limpo(b.ano)})</strong>
                <span class="badge ${b.aberto ? 'Publicado' : 'Devolvido'}">
                  ${b.aberto ? 'Janela Aberta' : 'Janela Fechada'}
                </span>
              </div>
              <div class="form-grid" style="margin-top:12px;">
                <label class="field">
                  Abertura da Digitação
                  <input type="datetime-local" name="data_abertura" value="${abertura}" required>
                </label>
                <label class="field">
                  Encerramento da Digitação
                  <input type="datetime-local" name="data_encerramento" value="${encerramento}" required>
                </label>
                <label class="field">
                  Status do Período
                  <select name="aberto">
                    <option value="1" ${b.aberto ? 'selected' : ''}>Aberto para Professores</option>
                    <option value="0" ${!b.aberto ? 'selected' : ''}>Encerrado / Bloqueado</option>
                  </select>
                </label>
              </div>
              <div class="record-actions">
                <button class="small-button" type="submit">Salvar Período</button>
              </div>
            </form>
          `;
        })
        .join('');

      container.querySelectorAll('.form-bimestre').forEach(form => {
        form.onsubmit = async e => {
          e.preventDefault();
          const f = new FormData(form);
          try {
            await api.atualizar('bimestres', form.dataset.id, {
              data_abertura: f.get('data_abertura').replace('T', ' ') + ':00',
              data_encerramento: f.get('data_encerramento').replace('T', ' ') + ':00',
              aberto: Number(f.get('aberto'))
            });
            await carregar();
            aviso('Período bimestral atualizado com sucesso!');
          } catch (err) {
            aviso(err.message, 'error');
          }
        };
      });
    } catch (err) {
      container.className = '';
      container.innerHTML = `<div class="message error">${limpo(err.message)}</div>`;
    }
  }

  await carregar();
}

async function telaRevisaoAdmin() {
  casca(
    titulos.revisao,
    `
      <div class="panel">
        <strong>FILTRAR ACOMPANHAMENTOS PARA REVISÃO</strong>
        <div class="filter">
          <select id="filtro-status">
            <option value="">Todos os Status</option>
            <option value="Pendente">Enviados para Revisão (Pendente)</option>
            <option value="Em revisão">Em revisão</option>
            <option value="Devolvido">Devolvidos ao Professor</option>
            <option value="Publicado">Publicados aos Pais</option>
            <option value="Rascunho">Rascunhos</option>
          </select>
        </div>
      </div>

      <div id="lista-revisao" class="loading">Carregando registros para revisão...</div>
    `
  );

  const container = document.querySelector('#lista-revisao');
  const selectStatus = document.querySelector('#filtro-status');

  async function carregar() {
    container.className = 'loading';
    container.textContent = 'Buscando registros...';
    try {
      const query = selectStatus.value ? `status=${encodeURIComponent(selectStatus.value)}` : '';
      const itens = await api.listar('acompanhamentos', query);

      container.className = 'cards';
      if (!itens.length) {
        container.innerHTML = `<div class="panel">Nenhum acompanhamento encontrado para este filtro.</div>`;
        return;
      }

      container.innerHTML = itens
        .map(
          x => `
            <article class="record">
              <div class="record-head">
                <strong>
                  ALUNO: ${limpo(x.aluno)} · ${limpo(x.disciplina)} (${limpo(x.turma)} - ${limpo(x.bimestre)})
                </strong>
                <span class="badge ${x.status === 'Em revisão' ? 'Revisao' : limpo(x.status)}">
                  STATUS: ${limpo(x.status)}
                </span>
              </div>

              <div class="chips">
                ${(x.tags || []).map(t => `<span class="chip">${limpo(t)}</span>`).join('')}
              </div>

              <form class="form-revisao-item" data-id="${x.id}">
                <div class="form-grid">
                  <label class="field">
                    Média Bimestral (0 a 10)
                    <input type="number" step="0.1" min="0" max="10" name="media" value="${limpo(x.media)}" required>
                  </label>
                  <label class="field wide">
                    Parecer / Descrição (Editável pelo Revisor)
                    <textarea name="descricao" required>${limpo(x.descricao)}</textarea>
                  </label>
                  <label class="field wide">
                    Parecer da Coordenação / Motivo de Devolução
                    <input type="text" name="feedback_admin" value="${limpo(x.feedback_admin || '')}" placeholder="Observação interna ao professor">
                  </label>
                </div>

                ${
                  x.ciencia_data || x.observacao_responsavel
                    ? `
                      <div class="message success" style="margin-top:10px;">
                        <strong>Retorno da Família:</strong>
                        ${x.ciencia_data ? `Ciência confirmada em ${limpo(x.ciencia_data)}.` : ''}
                        ${x.observacao_responsavel ? `<br>Observação do Responsável: "${limpo(x.observacao_responsavel)}"` : ''}
                      </div>
                    `
                    : ''
                }

                <div class="record-actions">
                  <button type="submit" name="novoStatus" value="Em revisão" class="small-button secondary">
                    Marcar Em Revisão
                  </button>
                  <button type="submit" name="novoStatus" value="Devolvido" class="small-button warning">
                    Devolver para Ajustes
                  </button>
                  <button type="submit" name="novoStatus" value="Publicado" class="small-button success-btn">
                    Aprovar e Publicar aos Pais
                  </button>
                  <button type="button" class="small-button danger btn-excluir-acomp" data-id="${x.id}">
                    Excluir
                  </button>
                </div>
              </form>
            </article>
          `
        )
        .join('');

      container.querySelectorAll('.form-revisao-item').forEach(form => {
        form.onsubmit = async e => {
          e.preventDefault();
          const f = new FormData(form);
          const novoStatus = e.submitter.value;
          const sessao = obterSessao();

          try {
            await api.atualizar('acompanhamentos', form.dataset.id, {
              media: Number(f.get('media')),
              descricao: f.get('descricao'),
              feedback_admin: f.get('feedback_admin'),
              status: novoStatus,
              usuario_acao: sessao ? sessao.nome : 'Admin Coordenação',
              perfil: 'administrador',
              detalhes_auditoria: `Revisão administrativa: status alterado para ${novoStatus}`
            });
            await carregar();
            aviso(`Acompanhamento atualizado para "${novoStatus}" com registro na auditoria!`);
          } catch (err) {
            aviso(err.message, 'error');
          }
        };
      });

      container.querySelectorAll('.btn-excluir-acomp').forEach(btn => {
        btn.onclick = async () => {
          if (!window.confirm('Deseja realmente excluir este acompanhamento?')) return;
          try {
            await api.remover('acompanhamentos', btn.dataset.id);
            await carregar();
            aviso('Acompanhamento excluído com sucesso.');
          } catch (err) {
            aviso(err.message, 'error');
          }
        };
      });
    } catch (err) {
      container.innerHTML = `<div class="message error">${limpo(err.message)}</div>`;
    }
  }

  selectStatus.onchange = carregar;
  await carregar();
}

async function telaRelatoriosAdmin() {
  casca(
    titulos.relatorios,
    `
      <div class="stats" id="painel-indicadores">
        <div class="panel">Carregando indicadores...</div>
      </div>

      <div class="form-actions">
        <button class="primary" id="btn-exportar-excel">
          Exportar Relatório Completo para Excel (.CSV)
        </button>
      </div>

      <h2 class="section-title">HISTÓRICO DE AUDITORIA E RASTREABILIDADE (RF07)</h2>
      <div id="lista-auditoria" class="loading">Carregando trilha de auditoria...</div>
    `
  );

  try {
    const [acompanhamentos, historico] = await Promise.all([
      api.listar('acompanhamentos'),
      api.listar('historico')
    ]);

    const publicados = acompanhamentos.filter(a => a.status === 'Publicado').length;
    const pendentes = acompanhamentos.filter(
      a => a.status === 'Pendente' || a.status === 'Em revisão'
    ).length;
    const mediaGeral = acompanhamentos.length
      ? (acompanhamentos.reduce((acc, x) => acc + Number(x.media), 0) / acompanhamentos.length).toFixed(1)
      : '0.0';

    document.querySelector('#painel-indicadores').innerHTML = `
      <div class="panel">
        <strong>Total de Acompanhamentos</strong>
        <p>Registros no banco: <b>${acompanhamentos.length}</b></p>
        <p>Publicados aos pais: <b>${publicados}</b></p>
      </div>
      <div class="panel">
        <strong>Fluxo Editorial</strong>
        <p>Aguardando revisão: <b>${pendentes}</b></p>
        <p>Devolvidos para ajuste: <b>${acompanhamentos.filter(a => a.status === 'Devolvido').length}</b></p>
      </div>
      <div class="panel">
        <strong>Desempenho Acadêmico</strong>
        <p>Média Geral das Turmas: <b>${mediaGeral}</b></p>
        <p>Confirmações de Ciência: <b>${acompanhamentos.filter(a => a.ciencia_data).length}</b></p>
      </div>
    `;

    document.querySelector('#btn-exportar-excel').onclick = () => {
      const cabecalho = [
        'ID',
        'Ano',
        'Bimestre',
        'Turma',
        'Aluno',
        'Disciplina',
        'Professor',
        'Media',
        'Status',
        'Tags',
        'Descricao',
        'Ciencia Responsavel',
        'Observacao Responsavel'
      ];
      const linhas = acompanhamentos.map(a => [
        a.id,
        a.ano || '2026',
        a.bimestre,
        a.turma,
        a.aluno,
        a.disciplina,
        a.professor || 'Julio Cesar',
        String(a.media).replace('.', ','),
        a.status,
        (a.tags || []).join(' | '),
        String(a.descricao || '').replace(/[\r\n;]+/g, ' '),
        a.ciencia_data || 'Pendente',
        String(a.observacao_responsavel || '').replace(/[\r\n;]+/g, ' ')
      ]);

      const conteudoCsv =
        '\uFEFF' +
        [cabecalho.join(';'), ...linhas.map(l => l.map(v => `"${v}"`).join(';'))].join('\r\n');

      const blob = new Blob([conteudoCsv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `relatorio_kfka_${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(url);
      aviso('Arquivo .CSV compatível com Excel gerado com sucesso!');
    };

    const divAuditoria = document.querySelector('#lista-auditoria');
    divAuditoria.className = 'table-wrap';
    divAuditoria.innerHTML = `
      <table>
        <thead>
          <tr>
            <th>Data/Hora</th>
            <th>Usuário (Perfil)</th>
            <th>Aluno / Disciplina</th>
            <th>Estado Anterior</th>
            <th>Estado Posterior</th>
            <th>Detalhes da Ação</th>
          </tr>
        </thead>
        <tbody>
          ${historico
            .map(
              h => `
                <tr>
                  <td>${limpo(new Date(h.data_hora).toLocaleString('pt-BR'))}</td>
                  <td>${limpo(h.usuario)} (${limpo(h.perfil)})</td>
                  <td>${limpo(h.aluno || '#' + h.acompanhamento_id)} · ${limpo(h.disciplina || '')}</td>
                  <td>${limpo(h.estado_anterior)}</td>
                  <td><span class="badge ${limpo(h.estado_posterior)}">${limpo(h.estado_posterior)}</span></td>
                  <td>${limpo(h.detalhes)}</td>
                </tr>
              `
            )
            .join('')}
        </tbody>
      </table>
    `;
  } catch (err) {
    aviso(err.message, 'error');
  }
}

function fichaProfessor(x) {
  return `
    <article class="record">
      <div class="record-head">
        <strong>
          ♙ ALUNO: ${limpo(x.aluno)} · SALA: ${limpo(x.turma)} · ${limpo(x.disciplina)} (${limpo(x.bimestre)})
        </strong>
        <span class="badge ${limpo(x.status)}">
          STATUS: ${limpo(x.status)}
        </span>
      </div>

      <div class="chips">
        ${(x.tags || []).map(t => `<span class="chip">${limpo(t)}</span>`).join('')}
      </div>

      <p><strong>Média bimestral:</strong> ${limpo(x.media)}</p>
      <p><strong>Avaliação:</strong> ${limpo(x.descricao)}</p>

      ${
        x.feedback_admin
          ? `<p class="message"><strong>Retorno da Coordenação:</strong> ${limpo(x.feedback_admin)}</p>`
          : ''
      }
      ${
        x.ciencia_data || x.observacao_responsavel
          ? `
            <p class="message success">
              <strong>Retorno do Responsável:</strong>
              ${x.ciencia_data ? `Ciência confirmada em ${limpo(x.ciencia_data)}. ` : ''}
              ${x.observacao_responsavel ? `Mensagem: "${limpo(x.observacao_responsavel)}"` : ''}
            </p>
          `
          : ''
      }

      <div class="record-actions">
        <button class="small-button editar" data-id="${x.id}">
          Visualizar / Editar
        </button>
        <button class="small-button danger excluir-acomp" data-id="${x.id}">
          Excluir
        </button>
      </div>
    </article>
  `;
}

async function professor() {
  casca(
    titulos.professor,
    `
      <h1 class="section-title" id="info-janela">
        JANELA DE DIGITAÇÃO · Consultando período...
      </h1>

      <div class="panel" style="margin-bottom:16px;">
        <strong>MINHAS SALAS DE AULA (Clique para alternar a turma):</strong>
        <div id="botoes-salas-prof" class="filter" style="margin-top:8px; gap:8px; flex-wrap:wrap;"></div>
        <p id="resumo-alunos-sala" class="muted" style="margin-top:8px; margin-bottom:0; font-size:13px;"></p>
      </div>

      <div class="panel">
        <h2 id="titulo-form-prof">Lançar Acompanhamento da Turma</h2>
        <form id="acompanhamento">
          <div class="form-grid">
            <label class="field">
              Sala / Turma Selecionada
              <select name="turma" id="select-turma-prof" required></select>
            </label>

            <label class="field">
              Aluno (Matriculado nesta sala)
              <select name="aluno" id="select-aluno-prof" required></select>
            </label>

            <label class="field">
              Disciplina (Lecionada por você)
              <select name="disciplina" id="select-disc-prof" required></select>
            </label>

            ${select('bimestre', 'Bimestre', [
              '1º Bimestre',
              '2º Bimestre',
              '3º Bimestre',
              '4º Bimestre'
            ])}

            <label class="field">
              Média bimestral (0 a 10)
              <input name="media" type="number" step="0.1" min="0" max="10" required>
            </label>

            <div class="wide field">
              Tags de acompanhamento
              <div class="check-row" id="check-tags-prof"></div>
            </div>

            <label class="field wide">
              Avaliação / descrição do professor
              <textarea name="descricao" minlength="10" required></textarea>
            </label>
          </div>

          <div class="record-actions">
            <button class="primary" type="submit" name="acao" value="Rascunho">
              Salvar rascunho
            </button>
            <button class="primary" type="submit" name="acao" value="Pendente">
              Enviar para revisão
            </button>
            <button class="small-button secondary hidden" type="button" id="cancelar-edicao-prof">
              Cancelar edição
            </button>
          </div>
        </form>
      </div>

      <h2 class="section-title" id="titulo-lista-turma">ACOMPANHAMENTOS DA SALA SELECIONADA</h2>
      <div id="lista" class="loading" role="status">
        Carregando acompanhamentos do MySQL...
      </div>
    `,
    '/professor'
  );

  const lista = document.querySelector('#lista');
  const form = document.querySelector('#acompanhamento');
  const btnCancelar = document.querySelector('#cancelar-edicao-prof');
  const tituloForm = document.querySelector('#titulo-form-prof');
  const selectTurma = document.querySelector('#select-turma-prof');
  const selectAluno = document.querySelector('#select-aluno-prof');
  const selectDisc = document.querySelector('#select-disc-prof');
  const tituloListaTurma = document.querySelector('#titulo-lista-turma');
  const divBotoesSalas = document.querySelector('#botoes-salas-prof');
  const resumoAlunosSala = document.querySelector('#resumo-alunos-sala');

  let todosAlunos = [];
  let salasDoProfessor = [];
  let disciplinasDoProfessor = [];

  function desenharBotoesSalas() {
    const salaAtual = selectTurma.value;
    divBotoesSalas.innerHTML = salasDoProfessor
      .map(sala => {
        const qtd = todosAlunos.filter(
          a =>
            normalizarTexto(a.serie) === normalizarTexto(sala) &&
            (a.ativo === undefined || Boolean(a.ativo))
        ).length;
        const ativo = normalizarTexto(sala) === normalizarTexto(salaAtual) ? 'active-tab' : 'secondary';
        return `
          <button type="button" class="small-button ${ativo} btn-trocar-sala" data-sala="${limpo(sala)}">
            ${limpo(sala)} (${qtd} aluno${qtd === 1 ? '' : 's'})
          </button>
        `;
      })
      .join('');

    divBotoesSalas.querySelectorAll('.btn-trocar-sala').forEach(btn => {
      btn.onclick = () => {
        selectTurma.value = btn.dataset.sala;
        atualizarAlunosDaTurma(btn.dataset.sala);
        carregarAcompanhamentos();
      };
    });
  }

  function atualizarAlunosDaTurma(turmaEscolhida, alunoParaManter = '') {
    const alunosDaTurma = todosAlunos.filter(
      a =>
        normalizarTexto(a.serie) === normalizarTexto(turmaEscolhida) &&
        (a.ativo === undefined || Boolean(a.ativo))
    );

    if (!alunosDaTurma.length) {
      selectAluno.innerHTML = `<option value="">Nenhum aluno matriculado na sala ${limpo(turmaEscolhida)}</option>`;
      resumoAlunosSala.innerHTML = `A sala <b>${limpo(turmaEscolhida)}</b> ainda não possui alunos matriculados. O Administrador pode matricular alunos nela em <b>Alunos</b>.`;
    } else {
      selectAluno.innerHTML = alunosDaTurma
        .map(a => `<option value="${limpo(a.nome)}">${limpo(a.nome)} (Matrícula: ${limpo(a.matricula)})</option>`)
        .join('');
      if (alunoParaManter) {
        selectAluno.value = alunoParaManter;
      }
      resumoAlunosSala.innerHTML = `Mostrando <b>${alunosDaTurma.length} aluno(s)</b> matriculado(s) na sala <b>${limpo(turmaEscolhida)}</b>: ${alunosDaTurma.map(a => limpo(a.nome)).join(', ')}.`;
    }

    tituloListaTurma.textContent = `ACOMPANHAMENTOS DA SALA: ${String(turmaEscolhida || '').toUpperCase()}`;
    desenharBotoesSalas();
  }

  try {
    const [alunos, disciplinas, tagsBanco, bimestres, turmasBanco, professoresBanco] =
      await Promise.all([
        api.listar('alunos'),
        api.listar('disciplinas'),
        api.listar('tags'),
        api.listar('bimestres'),
        api.listar('turmas'),
        api.listar('professores')
      ]);

    if (caminho() !== 'professor') return;

    todosAlunos = alunos;

    const bimAtual = bimestres.find(b => b.nome === '2º Bimestre') || bimestres[0];
    if (bimAtual) {
      const dataFim = new Date(bimAtual.data_encerramento).toLocaleString('pt-BR');
      document.querySelector('#info-janela').textContent = bimAtual.aberto
        ? `JANELA DE DIGITAÇÃO ABERTA (${bimAtual.nome}) · Encerramento em ${dataFim}`
        : `JANELA DE DIGITAÇÃO ENCERRADA (${bimAtual.nome})`;
    }

    const sessao = obterSessao();
    const cadastrosDoProf = sessao
      ? professoresBanco.filter(
          p =>
            (p.ativo === undefined || Boolean(p.ativo)) &&
            (normalizarTexto(p.ra) === normalizarTexto(sessao.identificador) ||
              normalizarTexto(p.email) === normalizarTexto(sessao.email) ||
              normalizarTexto(p.nome) === normalizarTexto(sessao.nome) ||
              normalizarTexto(sessao.nome).includes(normalizarTexto(p.nome)))
        )
      : [];

    const salasVinculadas = [];
    const discVinculadas = [];

    cadastrosDoProf.forEach(reg => {
      String(reg.turma || '')
        .split(/[,;]/)
        .map(s => s.trim())
        .filter(Boolean)
        .forEach(s => salasVinculadas.push(s));

      String(reg.disciplina || '')
        .split(/[,;]/)
        .map(d => d.trim())
        .filter(Boolean)
        .forEach(d => discVinculadas.push(d));
    });

    const salasAtivasBanco = turmasBanco
      .filter(t => t.ativo === undefined || Boolean(t.ativo))
      .map(t => String(t.nome).trim());

    if (salasVinculadas.length > 0) {
      salasDoProfessor = [...new Set(salasVinculadas)];
    } else {
      salasDoProfessor = [
        ...new Set([...salasAtivasBanco, '6º Ano B', '7º Ano B'])
      ];
    }

    selectTurma.innerHTML = salasDoProfessor
      .map(nomeTurma => `<option value="${limpo(nomeTurma)}">${limpo(nomeTurma)}</option>`)
      .join('');

    atualizarAlunosDaTurma(selectTurma.value);

    if (discVinculadas.length > 0) {
      disciplinasDoProfessor = [...new Set(discVinculadas)];
    } else {
      disciplinasDoProfessor = disciplinas.length
        ? disciplinas.map(d => d.nome)
        : ['Matemática', 'Ciências'];
    }

    selectDisc.innerHTML = disciplinasDoProfessor
      .map(nomeDisc => `<option value="${limpo(nomeDisc)}">${limpo(nomeDisc)}</option>`)
      .join('');

    const listaTags = tagsBanco.length
      ? tagsBanco.map(t => t.nome)
      : ['Participação ativa', 'Trabalhos entregues', 'Acompanha a aula'];

    document.querySelector('#check-tags-prof').innerHTML = listaTags
      .map(t => `<label><input type="checkbox" name="tags" value="${limpo(t)}">${limpo(t)}</label>`)
      .join('');
  } catch (err) {
    aviso(err.message, 'error');
  }

  function limparFormularioProf() {
    const turmaAtual = selectTurma.value;
    delete form.dataset.editar;
    form.reset();
    selectTurma.value = turmaAtual;
    atualizarAlunosDaTurma(turmaAtual);
    tituloForm.textContent = 'Lançar Acompanhamento da Turma';
    btnCancelar.classList.add('hidden');
  }

  btnCancelar.onclick = limparFormularioProf;

  async function carregarAcompanhamentos() {
    lista.className = 'loading';
    lista.textContent = 'Carregando acompanhamentos da turma...';
    try {
      const turmaSelecionada = selectTurma.value;
      const query = turmaSelecionada ? `turma=${encodeURIComponent(turmaSelecionada)}` : '';
      const itens = await api.listar('acompanhamentos', query);
      if (caminho() !== 'professor') return;

      const itensFiltrados =
        disciplinasDoProfessor.length > 0
          ? itens.filter(item =>
              disciplinasDoProfessor.some(
                d => normalizarTexto(d) === normalizarTexto(item.disciplina)
              )
            )
          : itens;

      lista.className = 'cards';
      lista.innerHTML = itensFiltrados.length
        ? itensFiltrados.map(fichaProfessor).join('')
        : `<div class="panel">Nenhum acompanhamento registrado para suas disciplinas (${limpo(disciplinasDoProfessor.join(', '))}) na sala <b>${limpo(turmaSelecionada)}</b> ainda.</div>`;

      lista.querySelectorAll('.editar').forEach(b => {
        b.onclick = async () => {
          try {
            const x = await api.buscarPorId('acompanhamentos', b.dataset.id);
            selectTurma.value = x.turma;
            atualizarAlunosDaTurma(x.turma, x.aluno);
            form.disciplina.value = x.disciplina;
            form.bimestre.value = x.bimestre;
            form.media.value = x.media;
            form.descricao.value = x.descricao;
            form.querySelectorAll('[name=tags]').forEach(el => {
              el.checked = (x.tags || []).includes(el.value);
            });
            form.dataset.editar = x.id;
            tituloForm.textContent = `Editando Acompanhamento #${x.id} (${x.aluno})`;
            btnCancelar.classList.remove('hidden');
            form.scrollIntoView({ behavior: 'smooth' });
          } catch (err) {
            aviso(err.message, 'error');
          }
        };
      });

      lista.querySelectorAll('.excluir-acomp').forEach(b => {
        b.onclick = async () => {
          if (!window.confirm('Deseja realmente excluir este acompanhamento?')) return;
          try {
            await api.remover('acompanhamentos', b.dataset.id);
            await carregarAcompanhamentos();
            aviso('Acompanhamento removido com sucesso.');
          } catch (err) {
            aviso(err.message, 'error');
          }
        };
      });
    } catch (e) {
      lista.innerHTML = `<div class="message error">${limpo(e.message)}<button id="repetir">Tentar novamente</button></div>`;
      document.querySelector('#repetir').onclick = carregarAcompanhamentos;
    }
  }

  selectTurma.onchange = () => {
    atualizarAlunosDaTurma(selectTurma.value);
    carregarAcompanhamentos();
  };

  await carregarAcompanhamentos();

  form.onsubmit = async e => {
    e.preventDefault();
    if (!form.reportValidity()) return;

    const data = new FormData(form);
    if (!data.get('aluno')) {
      return aviso('Não há aluno selecionado nesta sala. Matricule um aluno nesta turma pelo painel do Admin.', 'error');
    }

    const media = Number(data.get('media'));
    if (media < 0 || media > 10) return aviso('A média deve estar entre 0 e 10.', 'error');
    const tags = data.getAll('tags');
    if (!tags.length) return aviso('Selecione ao menos uma tag.', 'error');

    const sessao = obterSessao();
    const payload = {
      turma: data.get('turma'),
      aluno: data.get('aluno'),
      disciplina: data.get('disciplina'),
      bimestre: data.get('bimestre'),
      media: media.toFixed(1),
      descricao: data.get('descricao'),
      tags,
      status: e.submitter.value,
      professor: sessao ? sessao.nome : 'Julio Cesar',
      usuario_acao: sessao ? sessao.nome : 'Prof. Julio Cesar',
      perfil: 'professor'
    };

    try {
      const editId = form.dataset.editar;
      if (editId) await api.atualizar('acompanhamentos', editId, payload);
      else await api.criar('acompanhamentos', payload);

      limparFormularioProf();
      await carregarAcompanhamentos();
      aviso(payload.status === 'Rascunho' ? 'Rascunho salvo.' : 'Enviado para revisão!');
    } catch (err) {
      aviso(err.message, 'error');
    }
  };
}

async function aluno() {
  const numBimestre = parametrosUrl().get('bimestre') || '2';
  const nomeBimestre = `${numBimestre}º Bimestre`;
  const sessao = obterSessao();

  let meusDependentes = [];
  let dadosResponsavel = null;

  try {
    const [todosAlunos, todosResponsaveis] = await Promise.all([
      api.listar('alunos'),
      api.listar('responsaveis')
    ]);

    if (sessao && sessao.perfil === 'responsavel') {
      const nomeRespLogado = normalizarTexto(sessao.nome);
      const cpfLogado = String(sessao.identificador || '').trim();

      dadosResponsavel = todosResponsaveis.find(
        r => r.cpf === cpfLogado || normalizarTexto(r.nome) === nomeRespLogado
      );

      const nomesVinculadosNoCadastroResp = todosResponsaveis
        .filter(
          r => r.cpf === cpfLogado || normalizarTexto(r.nome) === nomeRespLogado
        )
        .map(r => normalizarTexto(r.aluno));

      meusDependentes = todosAlunos.filter(
        a =>
          normalizarTexto(a.responsavel) === nomeRespLogado ||
          nomesVinculadosNoCadastroResp.includes(normalizarTexto(a.nome))
      );

      if (!meusDependentes.length && dadosResponsavel && dadosResponsavel.aluno) {
        meusDependentes = [
          {
            nome: dadosResponsavel.aluno,
            serie: 'Turma vinculada',
            matricula: '—'
          }
        ];
      }
    }

    if (!meusDependentes.length) {
      meusDependentes = todosAlunos.length
        ? todosAlunos
        : [{ nome: 'Lucas Sevino', serie: '6º Ano B', matricula: '23011232' }];
    }
  } catch {
    meusDependentes = [{ nome: 'Lucas Sevino', serie: '6º Ano B', matricula: '23011232' }];
  }

  const paramAluno = parametrosUrl().get('aluno');
  const alunoObjAtual =
    meusDependentes.find(a => a.nome === paramAluno) || meusDependentes[0];
  const alunoSelecionado = alunoObjAtual.nome;

  casca(
    titulos.aluno,
    `
      <div class="panel">
        <div class="filter" style="margin:0; justify-content:space-between; flex-wrap:wrap; gap:12px;">
          <div>
            <strong>Responsável Logado:</strong> ${limpo(sessao ? sessao.nome : 'Visitante')}
            ${dadosResponsavel ? ` · <b>CPF:</b> ${limpo(dadosResponsavel.cpf)} · <b>Parentesco:</b> ${limpo(dadosResponsavel.parentesco)}` : ''}
          </div>
          <div>
            <strong>Aluno vinculado: </strong>
            <select id="seletor-dependente">
              ${meusDependentes
                .map(
                  d => `
                    <option value="${limpo(d.nome)}" ${d.nome === alunoSelecionado ? 'selected' : ''}>
                      ${limpo(d.nome)} (${limpo(d.serie || '6º Ano B')}${d.matricula ? ' - Mat: ' + limpo(d.matricula) : ''})
                    </option>
                  `
                )
                .join('')}
            </select>
          </div>
          <nav class="filter" style="margin:0;" aria-label="Bimestres">
            ${[1, 2, 3, 4]
              .map(
                n => `
                  <a
                    class="small-button ${String(n) === String(numBimestre) ? 'active-tab' : ''}"
                    href="#/aluno?bimestre=${n}&aluno=${encodeURIComponent(alunoSelecionado)}"
                  >
                    ${n}º Bimestre
                  </a>
                `
              )
              .join('')}
          </nav>
        </div>
      </div>

      <div class="stats">
        <div class="panel">
          <strong>Resumo do ${limpo(nomeBimestre)}</strong>
          <p id="resumo-status">Status: Consultando...</p>
          <p>Média geral do bimestre: <b id="resumo-media">-</b></p>
          <p>Sala / Turma do Aluno: <b>${limpo(alunoObjAtual.serie || '6º Ano B')}</b></p>
        </div>

        <div class="panel" id="form-mensagem-box">
          <strong>Comunicação com a Escola (RF12)</strong>
          <form id="mensagem">
            <label class="field">
              Digite sua observação sobre o relatório
              <textarea name="mensagem" minlength="5" required placeholder="Sua mensagem ficará visível ao Professor e à Coordenação"></textarea>
            </label>
            <button class="small-button" type="submit" style="margin-top:8px;">
              Enviar observação
            </button>
          </form>
        </div>

        <div class="panel" id="form-ciencia-box">
          <strong>Confirmação de Ciência (RF12)</strong>
          <p id="ciencia-estado">Consulte e confirme a ciência do relatório publicado.</p>
          <button class="small-button success-btn" id="ciencia">
            Confirmar Ciência
          </button>
        </div>
      </div>

      <h1 class="section-title">
        AVALIAÇÕES PUBLICADAS · ${limpo(alunoSelecionado.toUpperCase())} (${limpo(nomeBimestre)})
      </h1>

      <div id="lista" class="loading" role="status">
        Carregando relatórios publicados...
      </div>

      <div class="form-actions">
        <button id="pdf" class="primary">
          Baixar PDF / Imprimir Boletim (RF09)
        </button>
      </div>
    `,
    '/aluno'
  );

  document.querySelector('#seletor-dependente').onchange = e => {
    location.hash = `#/aluno?bimestre=${numBimestre}&aluno=${encodeURIComponent(e.target.value)}`;
  };

  let publicados = [];

  try {
    const query = `bimestre=${encodeURIComponent(nomeBimestre)}&aluno=${encodeURIComponent(alunoSelecionado)}&status=Publicado`;
    publicados = await api.listar('acompanhamentos', query);
  } catch (e) {
    document.querySelector('#lista').innerHTML = `
      <div class="message error">
        ${limpo(e.message)}
        <button class="small-button" id="repetir">Tentar novamente</button>
      </div>
    `;
    document.querySelector('#repetir').onclick = aluno;
    return;
  }

  if (caminho() !== 'aluno') return;

  const mediaGeral = publicados.length
    ? (publicados.reduce((acc, x) => acc + Number(x.media), 0) / publicados.length)
        .toFixed(1)
        .replace('.', ',')
    : '—';

  document.querySelector('#resumo-media').textContent = mediaGeral;
  document.querySelector('#resumo-status').textContent = publicados.length
    ? `Status: ${publicados.length} disciplina(s) publicada(s) pela coordenação`
    : 'Status: Aguardando publicação pela coordenação';

  const jaCiente = publicados.find(p => p.ciencia_data);
  if (jaCiente) {
    document.querySelector('#ciencia-estado').textContent =
      `Ciência registrada em ${jaCiente.ciencia_data}`;
  }

  document.querySelector('#lista').className = 'cards';
  document.querySelector('#lista').innerHTML = publicados.length
    ? publicados
        .map(
          x => `
            <article class="record">
              <div class="record-head">
                <strong>${limpo(x.disciplina).toUpperCase()} (Prof. ${limpo(x.professor || 'Julio Cesar')})</strong>
                <strong>Média Bimestral: ${limpo(x.media)}</strong>
              </div>
              <div class="chips">
                ${(x.tags || []).map(t => `<span class="chip">${limpo(t)}</span>`).join('')}
              </div>
              <p><strong>Avaliação do professor:</strong> ${limpo(x.descricao)}</p>
              ${
                x.observacao_responsavel
                  ? `<p class="muted"><strong>Sua observação registrada:</strong> "${limpo(x.observacao_responsavel)}"</p>`
                  : ''
              }
            </article>
          `
        )
        .join('')
    : `
      <div class="panel">
        Ainda não há relatórios publicados pela coordenação para ${limpo(alunoSelecionado)} no ${limpo(nomeBimestre)}.
      </div>
    `;

  document.querySelector('#ciencia').onclick = async () => {
    if (!publicados.length) {
      return aviso('Não há relatórios publicados neste bimestre para confirmar ciência.', 'error');
    }
    const dataAtual = new Date().toLocaleString('pt-BR');
    try {
      await Promise.all(
        publicados.map(pub =>
          api.atualizar('acompanhamentos', pub.id, {
            acao_responsavel: true,
            ciencia_data: dataAtual
          })
        )
      );
      document.querySelector('#ciencia-estado').textContent = `Ciência registrada em ${dataAtual}`;
      aviso('Confirmação de ciência gravada com sucesso no banco de dados!');
    } catch (err) {
      aviso(err.message, 'error');
    }
  };

  document.querySelector('#mensagem').onsubmit = async e => {
    e.preventDefault();
    if (!e.target.reportValidity()) return;
    if (!publicados.length) {
      return aviso('A observação só pode ser vinculada quando houver relatório publicado.', 'error');
    }

    const texto = new FormData(e.target).get('mensagem');
    try {
      await Promise.all(
        publicados.map(pub =>
          api.atualizar('acompanhamentos', pub.id, {
            acao_responsavel: true,
            observacao_responsavel: texto
          })
        )
      );
      e.target.reset();
      await aluno();
      aviso('Observação enviada e vinculada ao relatório para o Professor e Coordenação!');
    } catch (err) {
      aviso(err.message, 'error');
    }
  };

  document.querySelector('#pdf').onclick = () => window.print();
}

function rota() {
  const r = caminho();

  if (r === 'login') {
    acesso();
  } else if (r === 'acesso') {
    telaAcesso();
  } else if (r === 'administrador') {
    menuAdmin();
  } else if (r === 'bimestres') {
    telaBimestres();
  } else if (r === 'revisao') {
    telaRevisaoAdmin();
  } else if (r === 'relatorios') {
    telaRelatoriosAdmin();
  } else if (r === 'professor') {
    professor();
  } else if (r === 'aluno') {
    aluno();
  } else if (configs[r]) {
    cadastro(r);
  } else {
    casca(
      'Página não encontrada',
      `
        <div class="notfound">
          <h1>404 · Página não encontrada</h1>
          <p>Este endereço não existe.</p>
          <a class="primary" href="#/login">Voltar ao início</a>
        </div>
      `,
      '/login'
    );
  }
}

window.addEventListener('hashchange', rota);
rota();