const pool = require('../config/db');

class EntidadeBase {
  constructor(tabela) {
    this.tabela = tabela;
  }

  async listarTodos(ordem = 'id DESC') {
    const [rows] = await pool.query(`SELECT * FROM ${this.tabela} ORDER BY ${ordem}`);
    return rows;
  }

  async buscarPorId(id) {
    const [rows] = await pool.query(`SELECT * FROM ${this.tabela} WHERE id = ?`, [id]);
    return rows[0] || null;
  }

  async remover(id) {
    const [res] = await pool.query(`DELETE FROM ${this.tabela} WHERE id = ?`, [id]);
    return res.affectedRows > 0;
  }
}

class SistemaKFKA {
  constructor() {
    this.turmas = new EntidadeBase('turmas');
    this.disciplinas = new EntidadeBase('disciplinas');
    this.professores = new EntidadeBase('professores');
    this.responsaveis = new EntidadeBase('responsaveis');
    this.alunos = new EntidadeBase('alunos');
    this.tags = new EntidadeBase('tags');
    this.bimestres = new EntidadeBase('bimestres');
  }

  // =========================================================================
  // AUTENTICAÇÃO, PRIMEIRO ACESSO E SINCRONIZAÇÃO DE USUÁRIOS (RF01)
  // =========================================================================

  async autenticar(identificador, senha, perfil) {
    const idLimpo = String(identificador || '').trim();
    const senhaLimpa = String(senha || '').trim();

    // 1. Busca direta na tabela de usuários (por identificador ou email)
    let [rows] = await pool.query(
      `SELECT id, nome, identificador, email, perfil, ativo, senha
       FROM usuarios
       WHERE (identificador = ? OR email = ?) AND perfil = ?`,
      [idLimpo, idLimpo, perfil]
    );

    // 2. Se for responsável, permite logar também usando a MATRÍCULA do aluno ou CPF cadastrado em 'responsaveis'
    if (!rows.length && perfil === 'responsavel') {
      const [respRows] = await pool.query(
        `SELECT r.* FROM responsaveis r
         LEFT JOIN alunos a ON (a.responsavel = r.nome OR a.nome = r.aluno)
         WHERE r.cpf = ? OR r.email = ? OR a.matricula = ?
         LIMIT 1`,
        [idLimpo, idLimpo, idLimpo]
      );

      if (respRows.length) {
        const resp = respRows[0];
        const [uRows] = await pool.query(
          `SELECT * FROM usuarios WHERE identificador = ? AND perfil = 'responsavel'`,
          [resp.cpf]
        );

        if (uRows.length) {
          rows = uRows;
        } else {
          // Cria automaticamente o usuário caso tenha sido cadastrado antes na tabela responsaveis
          const [ins] = await pool.query(
            `INSERT INTO usuarios (nome, identificador, email, senha, perfil, ativo)
             VALUES (?, ?, ?, '123456', 'responsavel', 1)`,
            [resp.nome, resp.cpf, resp.email]
          );
          rows = [
            {
              id: ins.insertId,
              nome: resp.nome,
              identificador: resp.cpf,
              email: resp.email,
              perfil: 'responsavel',
              ativo: 1,
              senha: '123456'
            }
          ];
        }
      }
    }

    // 3. Se for professor, permite logar com o RA cadastrado na tabela 'professores'
    if (!rows.length && perfil === 'professor') {
      const [profRows] = await pool.query(
        `SELECT * FROM professores WHERE ra = ? OR email = ? LIMIT 1`,
        [idLimpo, idLimpo]
      );
      if (profRows.length) {
        const prof = profRows[0];
        const [ins] = await pool.query(
          `INSERT IGNORE INTO usuarios (nome, identificador, email, senha, perfil, ativo)
           VALUES (?, ?, ?, '123456', 'professor', 1)`,
          [prof.nome, prof.ra, prof.email]
        );
        const [uRows] = await pool.query(
          `SELECT * FROM usuarios WHERE identificador = ? AND perfil = 'professor'`,
          [prof.ra]
        );
        rows = uRows;
      }
    }

    if (!rows.length) {
      throw new Error('Usuário ou matrícula não encontrados para este perfil.');
    }

    const usuario = rows[0];
    if (usuario.senha !== senhaLimpa) {
      throw new Error('Senha incorreta. Se for seu primeiro acesso, clique em "Criar / Definir Senha".');
    }

    if (!usuario.ativo) {
      throw new Error('Esta conta está inativa. Contate a coordenação.');
    }

    delete usuario.senha;
    return usuario;
  }

  async definirSenhaResponsavel(identificador, novaSenha) {
    const idLimpo = String(identificador || '').trim();
    const senhaLimpa = String(novaSenha || '').trim();

    if (!idLimpo || senhaLimpa.length < 4) {
      throw new Error('Informe o CPF ou Matrícula do aluno e uma senha de pelo menos 4 dígitos.');
    }

    // Procura o responsável pelo CPF, E-mail ou Matrícula do Aluno vinculado
    const [respRows] = await pool.query(
      `SELECT r.* FROM responsaveis r
       LEFT JOIN alunos a ON (a.responsavel = r.nome OR a.nome = r.aluno)
       WHERE r.cpf = ? OR r.email = ? OR a.matricula = ?
       LIMIT 1`,
      [idLimpo, idLimpo, idLimpo]
    );

    if (!respRows.length) {
      throw new Error(
        'Responsável ou matrícula não encontrados! Peça ao Administrador para cadastrar o responsável primeiro.'
      );
    }

    const resp = respRows[0];

    const [existentes] = await pool.query(
      `SELECT id FROM usuarios WHERE identificador = ? AND perfil = 'responsavel'`,
      [resp.cpf]
    );

    if (existentes.length) {
      await pool.query(`UPDATE usuarios SET senha = ?, nome = ?, email = ? WHERE id = ?`, [
        senhaLimpa,
        resp.nome,
        resp.email,
        existentes[0].id
      ]);
    } else {
      await pool.query(
        `INSERT INTO usuarios (nome, identificador, email, senha, perfil, ativo)
         VALUES (?, ?, ?, ?, 'responsavel', 1)`,
        [resp.nome, resp.cpf, resp.email, senhaLimpa]
      );
    }

    return {
      mensagem: `Senha criada com sucesso para ${resp.nome}! Agora você pode entrar usando seu CPF (${resp.cpf}) ou a matrícula do aluno.`
    };
  }

  async recuperarSenha(identificador) {
    const [rows] = await pool.query(
      `SELECT email, nome, senha FROM usuarios WHERE identificador = ? OR email = ?`,
      [identificador, identificador]
    );
    if (!rows.length) {
      throw new Error('Identificador não localizado na base de usuários.');
    }
    return {
      mensagem: `Olá ${rows[0].nome}, instruções enviadas para ${rows[0].email} (Senha atual: ${rows[0].senha}).`
    };
  }

  // =========================================================================
  // OPERAÇÕES DE CADASTRO (RF02, RF03, RF04)
  // =========================================================================

  async listarEntidade(rota) {
    if (!this[rota]) throw new Error('Entidade inválida.');
    return await this[rota].listarTodos();
  }

  async buscarEntidadePorId(rota, id) {
    if (!this[rota]) throw new Error('Entidade inválida.');
    const item = await this[rota].buscarPorId(id);
    if (!item) throw new Error('Registro não encontrado.');
    return item;
  }

  async criarEntidade(rota, dados) {
    if (rota === 'turmas') {
      const { ano = '2026', nome, turno, capacidade, disciplinas } = dados;
      const [res] = await pool.query(
        `INSERT INTO turmas (ano, nome, turno, capacidade, disciplinas) VALUES (?, ?, ?, ?, ?)`,
        [ano, nome, turno, Number(capacidade), disciplinas]
      );
      return await this.turmas.buscarPorId(res.insertId);
    }

    if (rota === 'disciplinas') {
      const { nome, area } = dados;
      const [res] = await pool.query(
        `INSERT INTO disciplinas (nome, area) VALUES (?, ?)`,
        [nome, area]
      );
      return await this.disciplinas.buscarPorId(res.insertId);
    }

    if (rota === 'professores') {
      const { nome, ra, email, turma, disciplina, senha } = dados;
      const aulas = `${turma} • ${disciplina}`;
      const [res] = await pool.query(
        `INSERT INTO professores (nome, ra, email, turma, disciplina, aulas) VALUES (?, ?, ?, ?, ?, ?)`,
        [nome, ra, email, turma, disciplina, aulas]
      );

      // Cria automaticamente o login do professor
      const senhaInicial = senha && String(senha).trim() ? String(senha).trim() : '123456';
      await pool.query(
        `INSERT INTO usuarios (nome, identificador, email, senha, perfil, ativo)
         VALUES (?, ?, ?, ?, 'professor', 1)
         ON DUPLICATE KEY UPDATE nome = VALUES(nome), email = VALUES(email), senha = VALUES(senha)`,
        [nome, ra, email, senhaInicial]
      );

      return await this.professores.buscarPorId(res.insertId);
    }

    if (rota === 'responsaveis') {
      const { nome, email, telefone, cpf, parentesco, aluno, senha } = dados;
      const [res] = await pool.query(
        `INSERT INTO responsaveis (nome, email, telefone, cpf, parentesco, aluno) VALUES (?, ?, ?, ?, ?, ?)`,
        [nome, email, telefone, cpf, parentesco, aluno]
      );

      // Cria automaticamente o login do responsável na tabela usuarios
      const senhaInicial = senha && String(senha).trim() ? String(senha).trim() : '123456';
      await pool.query(
        `INSERT INTO usuarios (nome, identificador, email, senha, perfil, ativo)
         VALUES (?, ?, ?, ?, 'responsavel', 1)
         ON DUPLICATE KEY UPDATE nome = VALUES(nome), email = VALUES(email), senha = VALUES(senha)`,
        [nome, cpf, email, senhaInicial]
      );

      return await this.responsaveis.buscarPorId(res.insertId);
    }

    if (rota === 'alunos') {
      const { nome, matricula, serie, responsavel } = dados;
      const [res] = await pool.query(
        `INSERT INTO alunos (nome, matricula, serie, responsavel) VALUES (?, ?, ?, ?)`,
        [nome, matricula, serie, responsavel]
      );
      return await this.alunos.buscarPorId(res.insertId);
    }

    if (rota === 'tags') {
      const { nome, categoria = 'Desempenho' } = dados;
      const [res] = await pool.query(
        `INSERT INTO tags (nome, categoria) VALUES (?, ?)`,
        [nome, categoria]
      );
      return await this.tags.buscarPorId(res.insertId);
    }

    throw new Error('Rota de criação inválida.');
  }

  async atualizarEntidade(rota, id, dados) {
    const atual = await this.buscarEntidadePorId(rota, id);

    // Atualização parcial de status Ativo/Inativo
    if (Object.keys(dados).length === 1 && dados.ativo !== undefined) {
      await pool.query(`UPDATE ${rota} SET ativo = ? WHERE id = ?`, [Number(dados.ativo), id]);
      return await this.buscarEntidadePorId(rota, id);
    }

    if (rota === 'turmas') {
      const {
        ano = atual.ano,
        nome = atual.nome,
        turno = atual.turno,
        capacidade = atual.capacidade,
        disciplinas = atual.disciplinas
      } = dados;
      await pool.query(
        `UPDATE turmas SET ano = ?, nome = ?, turno = ?, capacidade = ?, disciplinas = ? WHERE id = ?`,
        [ano, nome, turno, Number(capacidade), disciplinas, id]
      );
    } else if (rota === 'disciplinas') {
      const { nome = atual.nome, area = atual.area } = dados;
      await pool.query(`UPDATE disciplinas SET nome = ?, area = ? WHERE id = ?`, [nome, area, id]);
    } else if (rota === 'professores') {
      const {
        nome = atual.nome,
        ra = atual.ra,
        email = atual.email,
        turma = atual.turma,
        disciplina = atual.disciplina
      } = dados;
      const aulas = `${turma} • ${disciplina}`;
      await pool.query(
        `UPDATE professores SET nome = ?, ra = ?, email = ?, turma = ?, disciplina = ?, aulas = ? WHERE id = ?`,
        [nome, ra, email, turma, disciplina, aulas, id]
      );
    } else if (rota === 'responsaveis') {
      const {
        nome = atual.nome,
        email = atual.email,
        telefone = atual.telefone,
        cpf = atual.cpf,
        parentesco = atual.parentesco,
        aluno = atual.aluno,
        senha
      } = dados;
      await pool.query(
        `UPDATE responsaveis SET nome = ?, email = ?, telefone = ?, cpf = ?, parentesco = ?, aluno = ? WHERE id = ?`,
        [nome, email, telefone, cpf, parentesco, aluno, id]
      );

      // Atualiza também o usuário de login correspondente
      if (senha && String(senha).trim()) {
        await pool.query(
          `INSERT INTO usuarios (nome, identificador, email, senha, perfil, ativo)
           VALUES (?, ?, ?, ?, 'responsavel', 1)
           ON DUPLICATE KEY UPDATE nome = VALUES(nome), email = VALUES(email), senha = VALUES(senha)`,
          [nome, cpf, email, String(senha).trim()]
        );
      } else {
        await pool.query(
          `UPDATE usuarios SET nome = ?, email = ?, identificador = ? WHERE identificador = ? AND perfil = 'responsavel'`,
          [nome, email, cpf, atual.cpf]
        );
      }
    } else if (rota === 'alunos') {
      const {
        nome = atual.nome,
        matricula = atual.matricula,
        serie = atual.serie,
        responsavel = atual.responsavel
      } = dados;
      await pool.query(
        `UPDATE alunos SET nome = ?, matricula = ?, serie = ?, responsavel = ? WHERE id = ?`,
        [nome, matricula, serie, responsavel, id]
      );
    } else if (rota === 'tags') {
      const { nome = atual.nome, categoria = atual.categoria } = dados;
      await pool.query(`UPDATE tags SET nome = ?, categoria = ? WHERE id = ?`, [
        nome,
        categoria,
        id
      ]);
    } else if (rota === 'bimestres') {
      const {
        data_abertura = atual.data_abertura,
        data_encerramento = atual.data_encerramento,
        aberto = atual.aberto
      } = dados;
      await pool.query(
        `UPDATE bimestres SET data_abertura = ?, data_encerramento = ?, aberto = ? WHERE id = ?`,
        [data_abertura, data_encerramento, Number(aberto), id]
      );
    }

    return await this.buscarEntidadePorId(rota, id);
  }

  async removerEntidade(rota, id) {
    if (!this[rota]) throw new Error('Entidade inválida.');
    const ok = await this[rota].remover(id);
    if (!ok) throw new Error('Registro não encontrado para exclusão.');
    return { mensagem: 'Registro removido com sucesso.' };
  }

  // =========================================================================
  // ACOMPANHAMENTOS E AUDITORIA (RF05, RF06, RF07, RF08, RF12)
  // =========================================================================

  _formatarAcompanhamento(row) {
    if (!row) return null;
    let tagsArray = [];
    try {
      tagsArray = typeof row.tags === 'string' ? JSON.parse(row.tags) : row.tags || [];
    } catch {
      tagsArray = String(row.tags || '')
        .split(',')
        .map(s => s.trim())
        .filter(Boolean);
    }
    return { ...row, tags: tagsArray };
  }

  async listarAcompanhamentos(filtros = {}) {
    let sql = `SELECT * FROM acompanhamentos WHERE 1=1`;
    const params = [];

    if (filtros.status) {
      sql += ` AND status = ?`;
      params.push(filtros.status);
    }
    if (filtros.bimestre) {
      sql += ` AND bimestre = ?`;
      params.push(filtros.bimestre);
    }
    if (filtros.aluno) {
      sql += ` AND aluno = ?`;
      params.push(filtros.aluno);
    }
    if (filtros.turma) {
      sql += ` AND turma = ?`;
      params.push(filtros.turma);
    }

    sql += ` ORDER BY id DESC`;
    const [rows] = await pool.query(sql, params);
    return rows.map(r => this._formatarAcompanhamento(r));
  }

  async buscarAcompanhamentoPorId(id) {
    const [rows] = await pool.query(`SELECT * FROM acompanhamentos WHERE id = ?`, [id]);
    if (!rows.length) throw new Error('Acompanhamento não encontrado.');
    return this._formatarAcompanhamento(rows[0]);
  }

  async criarAcompanhamento(dados) {
    const {
      aluno,
      disciplina,
      turma = '6º Ano B',
      bimestre,
      ano = '2026',
      professor = 'Julio Cesar',
      media,
      tags = [],
      descricao,
      status = 'Rascunho',
      usuario_acao = professor,
      perfil = 'professor'
    } = dados;

    const tagsJson = JSON.stringify(Array.isArray(tags) ? tags : [tags]);

    const [res] = await pool.query(
      `INSERT INTO acompanhamentos
       (aluno, disciplina, turma, bimestre, ano, professor, media, tags, descricao, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [aluno, disciplina, turma, bimestre, ano, professor, Number(media), tagsJson, descricao, status]
    );

    await this.registrarAuditoria(
      res.insertId,
      usuario_acao,
      perfil,
      'Novo',
      status,
      `Registro criado pelo professor na turma ${turma}`
    );

    return await this.buscarAcompanhamentoPorId(res.insertId);
  }

  async atualizarAcompanhamento(id, dados) {
    const atual = await this.buscarAcompanhamentoPorId(id);

    if (dados.acao_responsavel) {
      const ciencia = dados.ciencia_data !== undefined ? dados.ciencia_data : atual.ciencia_data;
      const obs =
        dados.observacao_responsavel !== undefined
          ? dados.observacao_responsavel
          : atual.observacao_responsavel;

      await pool.query(
        `UPDATE acompanhamentos SET ciencia_data = ?, observacao_responsavel = ? WHERE id = ?`,
        [ciencia, obs, id]
      );

      await this.registrarAuditoria(
        id,
        'Responsável da Família',
        'responsavel',
        atual.status,
        atual.status,
        dados.ciencia_data ? 'Responsável confirmou ciência do boletim' : 'Responsável enviou observação'
      );

      return await this.buscarAcompanhamentoPorId(id);
    }

    const {
      aluno = atual.aluno,
      disciplina = atual.disciplina,
      turma = atual.turma,
      bimestre = atual.bimestre,
      media = atual.media,
      tags = atual.tags,
      descricao = atual.descricao,
      status = atual.status,
      feedback_admin = atual.feedback_admin,
      usuario_acao = 'Usuário do Sistema',
      perfil = 'professor',
      detalhes_auditoria
    } = dados;

    const tagsJson = JSON.stringify(Array.isArray(tags) ? tags : [tags]);

    await pool.query(
      `UPDATE acompanhamentos
       SET aluno = ?, disciplina = ?, turma = ?, bimestre = ?, media = ?, tags = ?, descricao = ?, status = ?, feedback_admin = ?
       WHERE id = ?`,
      [
        aluno,
        disciplina,
        turma,
        bimestre,
        Number(media),
        tagsJson,
        descricao,
        status,
        feedback_admin,
        id
      ]
    );

    await this.registrarAuditoria(
      id,
      usuario_acao,
      perfil,
      atual.status,
      status,
      detalhes_auditoria || `Atualização do acompanhamento (${atual.status} -> ${status})`
    );

    return await this.buscarAcompanhamentoPorId(id);
  }

  async removerAcompanhamento(id) {
    const [res] = await pool.query(`DELETE FROM acompanhamentos WHERE id = ?`, [id]);
    if (!res.affectedRows) throw new Error('Acompanhamento não encontrado.');
    return { mensagem: 'Acompanhamento excluído com sucesso.' };
  }

  async registrarAuditoria(acompanhamentoId, usuario, perfil, estadoAnterior, estadoPosterior, detalhes) {
    await pool.query(
      `INSERT INTO historico_auditoria
       (acompanhamento_id, usuario, perfil, estado_anterior, estado_posterior, detalhes)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [acompanhamentoId, usuario, perfil, estadoAnterior, estadoPosterior, detalhes]
    );
  }

  async listarHistorico() {
    const [rows] = await pool.query(
      `SELECT h.*, a.aluno, a.disciplina
       FROM historico_auditoria h
       LEFT JOIN acompanhamentos a ON a.id = h.acompanhamento_id
       ORDER BY h.id DESC`
    );
    return rows;
  }
}

module.exports = new SistemaKFKA();