﻿using Microsoft.Data.Sqlite;

string conexao = "Data Source=alunos.db";

CriarBanco();
CadastrarAlunos();
MostrarAlunos();

void CriarBanco()
{
    using var banco = new SqliteConnection(conexao);
    banco.Open();

    var comando = banco.CreateCommand();

    comando.CommandText = @"
        CREATE TABLE IF NOT EXISTS Alunos (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nome TEXT,
            Curso TEXT
        )";

    comando.ExecuteNonQuery();
}

void CadastrarAlunos()
{
    using var banco = new SqliteConnection(conexao);
    banco.Open();

    var comando = banco.CreateCommand();

    comando.CommandText = @"
        INSERT INTO Alunos (Nome, Curso) VALUES
        ('Ana', 'Análise de Sistemas'),
        ('Bruno', 'Ciência da Computação'),
        ('Carla', 'Engenharia de Software'),
        ('Daniel', 'Ciência de Dados'),
        ('Eduarda', 'Análise de Sistemas'),
        ('Felipe', 'Ciência da Computação'),
        ('Gabriela', 'Engenharia de Software'),
        ('Henrique', 'Ciência de Dados'),
        ('Isabela', 'Análise de Sistemas'),
        ('João', 'Ciência da Computação')";

    try
    {
        comando.ExecuteNonQuery();
    }
    catch
    {
    }
}

void MostrarAlunos()
{
    int pagina = 1;
    int alunosPorPagina = 3;

    while (true)
    {
        Console.Clear();

        using var banco = new SqliteConnection(conexao);
        banco.Open();

        var comando = banco.CreateCommand();

        int inicio = (pagina - 1) * alunosPorPagina;

        comando.CommandText = $@"
            SELECT * FROM Alunos
            LIMIT {alunosPorPagina}
            OFFSET {inicio}";

        using var resultado = comando.ExecuteReader();

        Console.WriteLine("================================");
        Console.WriteLine("       LISTA DE ALUNOS");
        Console.WriteLine("================================");
        Console.WriteLine($"Página: {pagina}");
        Console.WriteLine();

        while (resultado.Read())
        {
            Console.WriteLine($"ID: {resultado["Id"]}");
            Console.WriteLine($"Nome: {resultado["Nome"]}");
            Console.WriteLine($"Curso: {resultado["Curso"]}");
            Console.WriteLine("--------------------------------");
        }

        Console.WriteLine();
        Console.WriteLine("P = Próxima página");
        Console.WriteLine("A = Página anterior");
        Console.WriteLine("S = Sair");
        Console.WriteLine();

        Console.Write("Digite uma opção: ");

        string opcao = Console.ReadLine()?.ToUpper() ?? "";

        if (opcao == "P")
        {
            pagina++;
        }
        else if (opcao == "A" && pagina > 1)
        {
            pagina--;
        }
        else if (opcao == "S")
        {
            break;
        }
    }
}
